const express = require('express');
const cors = require('cors');
const fs = require('fs'); // برای خواندن فایل‌ها
const path = require('path'); // برای کار با مسیر فایل‌ها
const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

// تابع برای بارگذاری دیتابیس
function loadProducts() {
    const filePath = path.join(__dirname, 'products.json'); // مسیر فایل دیتابیس
    const data = fs.readFileSync(filePath, 'utf8'); // خواندن فایل
    return JSON.parse(data); // تبدیل به آرایه
}

// endpoint برای برگردوندن همه محصولات
app.get('/products', (req, res) => {
    const products = loadProducts(); // بروزرسانی دیتابیس
    res.json(products);
});

// endpoint برای جست‌وجو
app.get('/search', (req, res) => {
    const products = loadProducts(); // بروزرسانی دیتابیس
    const query = req.query.q.toLowerCase();
    const results = products.filter(product => 
        product.title.toLowerCase().includes(query) ||
        product.brand.toLowerCase().includes(query) ||
        product.description.toLowerCase().includes(query)
    );
    if (results.length === 0) {
        res.status(404).json({ message: "نتیجه‌ای یافت نشد." });
    } else {
        res.json(results);
    }
});

app.listen(port, () => {
    console.log(`سرور در حال اجرا روی پورت ${port}`);
});